//
//  Images.swift
//  TheMovieSwiftUI
//
//  Created by Theint Su on 20/4/23.
//

import Foundation

let IC_HORIZONTAL_LINES = "line.3.horizontal"
let IC_MAGNIFYING_GLASS = "magnifyingglass"
let IC_PLAY_BUTTON = "play.circle.fill"
let IC_STAR_FILL = "star.fill"
let IC_STAR = "star"
let IG_MOVIE_POSTER = "movie_poster"
let IG_ACTOR = "actor"
let IG_MOVIE_POSTER2 = "yourname"
let IC_BACK = "chevron.left"
let IC_MAGNIFYINGGLASS = "magnifyingglass"
let IC_HEART = "heart"
let IC_CLOCK = "clock"

