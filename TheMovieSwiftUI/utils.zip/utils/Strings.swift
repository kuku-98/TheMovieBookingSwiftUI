//
//  Strings.swift
//  TheMovieSwiftUI
//
//  Created by Theint Su on 20/4/23.
//

import Foundation


let LABEL_DISCOVER = "Discover"
let LABEL_SHOWCASES = "SHOW CASES"
let LABEL_MORE_SHOWCASES = "MORE SHOWCASES"
let LABEL_STORY_LINE = "STORY_LINE"
let LABEL_ACTORS = "ACTORS"
let LABEL_BEST_ACTORS = "BEST ACTORS"
let LABEL_MORE_ACTORS = "MORE ACTORS"
let LABEL_CREATORS = "CREATORS"
let LABEL_MORE_CREATORS = "MORECREATORS"
let LABEL_ORIGINAL_TITLE = "Oringinal Title"
let LABEL_TYPE = "Type"
let LABEL_PRODUCTION = "Production"
let LABEL_ORIGINAL_RELEASE = "Original Release"
let LABEL_Description = "Description"
