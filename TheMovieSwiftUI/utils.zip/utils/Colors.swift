//
//  Colors.swift
//  TheMovieSwiftUI
//
//  Created by Theint Su on 20/4/23.
//

import Foundation


let PRIMARY_COLOR = "primary_color"
let PRIMARY_DARK_COLOR = "primary_dark_color"
let PRIMARY_LIGHT_COLOR = "primary_light_color"
let TITLE_LABLE_COLOR = "title_label_color"
